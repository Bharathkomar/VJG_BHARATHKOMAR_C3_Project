package TestPackage;

class Main {
    public static void main(String[] args) {
        AddEmpLeaves l1 = new AddEmpLeaves();
        System.out.println(l1.leaveValidity());
        System.out.println(l1.compOffValidity());
    }
}